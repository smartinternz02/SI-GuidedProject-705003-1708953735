<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>body_Solve this puzzle to protect your acco_6799c0</name>
   <tag></tag>
   <elementGuidId>fe21d319-26f3-423f-a6b4-30337c2c3484</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//body</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>body.a-m-us.a-aui_72554-c.a-aui_accordion_a11y_role_354025-c.a-aui_killswitch_csa_logger_372963-c.a-aui_launch_2021_ally_fixes_392482-c.a-aui_pci_risk_banner_210084-c.a-aui_preload_261698-c.a-aui_rel_noreferrer_noopener_309527-c.a-aui_template_weblab_cache_333406-c.a-aui_tnr_v2_180836-c.a-meter-animate</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>body</value>
      <webElementGuid>b33271a1-1a2a-4c3d-96e9-8b4ad469b281</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-m-us a-aui_72554-c a-aui_accordion_a11y_role_354025-c a-aui_killswitch_csa_logger_372963-c a-aui_launch_2021_ally_fixes_392482-c a-aui_pci_risk_banner_210084-c a-aui_preload_261698-c a-aui_rel_noreferrer_noopener_309527-c a-aui_template_weblab_cache_333406-c a-aui_tnr_v2_180836-c a-meter-animate</value>
      <webElementGuid>44b3ead8-63e6-4c87-8adb-3bf900426b20</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>{}






  
    

    
      



  
  

  
  
    
    
      

    
      
    
  


    
  










Solve this puzzle to protect your account






       Enter the letters and numbers above 





      
          See new characters
        
        
            Hear the characters
          

    
&lt;div class=&quot;a-row a-spacing-mini&quot;>&lt;span class=&quot;a-button a-button-span12 a-button-base cvf-widget-btn-captcha cvf-widget-btn-new-captcha&quot;>&lt;span class=&quot;a-button-inner&quot;>&lt;input name=&quot;cvf_captcha_captcha_action&quot; class=&quot;a-button-input notranslate&quot; type=&quot;submit&quot; value=&quot;newCaptcha&quot;/>&lt;span class=&quot;a-button-text&quot; aria-hidden=&quot;true&quot;>          See new characters
&lt;/span>&lt;/span>&lt;/span>&lt;/div>    

    
&lt;div class=&quot;a-row a-spacing-mini&quot;>&lt;span class=&quot;a-button a-button-span12 a-button-base cvf-widget-btn-captcha cvf-widget-btn-alternative-captcha&quot;>&lt;span class=&quot;a-button-inner&quot;>&lt;input name=&quot;cvf_captcha_captcha_action&quot; class=&quot;a-button-input notranslate&quot; type=&quot;submit&quot; value=&quot;alternativeCaptcha&quot;/>&lt;span class=&quot;a-button-text&quot; aria-hidden=&quot;true&quot;>          Hear the characters
&lt;/span>&lt;/span>&lt;/span>&lt;/div>    

Continue

  
    P.when('A').execute(function(A){
      var $ = A.$;
      $('#cvf_captcha_js_enabled_metric_id').val(&quot;1&quot;);
    });
  







  .auth-footer-separator {
    display: inline-block;
    width: 20px;
  }





  
    
      
    

    
      
        
          
        

        
      

      
        

        
          
            Conditions of Use
          
        
      

      
    
      
        
          
        

        
      

      
        

        
          
            Privacy Notice
          
        
      

      
    
      
        
          
        

        
      

      
        

        
          
            Help
          
        
      

      
    
  

  
    
      © 1996-2024, Amazon.com, Inc. or its affiliates
    
  



id(&quot;cvf-page-content&quot;)/div[@class=&quot;a-row a-spacing-none&quot;]/div[@class=&quot;a-box&quot;]/div[@class=&quot;a-box-inner a-padding-extra-large&quot;]/form[@class=&quot;cvf-widget-form cvf-widget-form-captcha fwcim-form a-spacing-none&quot;]/div[@class=&quot;a-row a-spacing-base&quot;]/input[@class=&quot;a-input-text a-span12 cvf-widget-input cvf-widget-input-code cvf-widget-input-captcha fwcim-captcha-guess&quot;]</value>
      <webElementGuid>04247efe-291d-4652-a71d-eb55c9eebefd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition null a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition&quot;]/body[@class=&quot;a-m-us a-aui_72554-c a-aui_accordion_a11y_role_354025-c a-aui_killswitch_csa_logger_372963-c a-aui_launch_2021_ally_fixes_392482-c a-aui_pci_risk_banner_210084-c a-aui_preload_261698-c a-aui_rel_noreferrer_noopener_309527-c a-aui_template_weblab_cache_333406-c a-aui_tnr_v2_180836-c a-meter-animate&quot;]</value>
      <webElementGuid>eb9f3656-6eef-4b93-ae75-3e1b9ac44fe8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//body</value>
      <webElementGuid>8c359b8c-528b-4c68-b5c3-2ab9fcfd16ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//body[(text() = concat(&quot;{}






  
    

    
      



  
  

  
  
    
    
      

    
      
    
  


    
  










Solve this puzzle to protect your account






       Enter the letters and numbers above 





      
          See new characters
        
        
            Hear the characters
          

    
&lt;div class=&quot;a-row a-spacing-mini&quot;>&lt;span class=&quot;a-button a-button-span12 a-button-base cvf-widget-btn-captcha cvf-widget-btn-new-captcha&quot;>&lt;span class=&quot;a-button-inner&quot;>&lt;input name=&quot;cvf_captcha_captcha_action&quot; class=&quot;a-button-input notranslate&quot; type=&quot;submit&quot; value=&quot;newCaptcha&quot;/>&lt;span class=&quot;a-button-text&quot; aria-hidden=&quot;true&quot;>          See new characters
&lt;/span>&lt;/span>&lt;/span>&lt;/div>    

    
&lt;div class=&quot;a-row a-spacing-mini&quot;>&lt;span class=&quot;a-button a-button-span12 a-button-base cvf-widget-btn-captcha cvf-widget-btn-alternative-captcha&quot;>&lt;span class=&quot;a-button-inner&quot;>&lt;input name=&quot;cvf_captcha_captcha_action&quot; class=&quot;a-button-input notranslate&quot; type=&quot;submit&quot; value=&quot;alternativeCaptcha&quot;/>&lt;span class=&quot;a-button-text&quot; aria-hidden=&quot;true&quot;>          Hear the characters
&lt;/span>&lt;/span>&lt;/span>&lt;/div>    

Continue

  
    P.when(&quot; , &quot;'&quot; , &quot;A&quot; , &quot;'&quot; , &quot;).execute(function(A){
      var $ = A.$;
      $(&quot; , &quot;'&quot; , &quot;#cvf_captcha_js_enabled_metric_id&quot; , &quot;'&quot; , &quot;).val(&quot;1&quot;);
    });
  







  .auth-footer-separator {
    display: inline-block;
    width: 20px;
  }





  
    
      
    

    
      
        
          
        

        
      

      
        

        
          
            Conditions of Use
          
        
      

      
    
      
        
          
        

        
      

      
        

        
          
            Privacy Notice
          
        
      

      
    
      
        
          
        

        
      

      
        

        
          
            Help
          
        
      

      
    
  

  
    
      © 1996-2024, Amazon.com, Inc. or its affiliates
    
  



id(&quot;cvf-page-content&quot;)/div[@class=&quot;a-row a-spacing-none&quot;]/div[@class=&quot;a-box&quot;]/div[@class=&quot;a-box-inner a-padding-extra-large&quot;]/form[@class=&quot;cvf-widget-form cvf-widget-form-captcha fwcim-form a-spacing-none&quot;]/div[@class=&quot;a-row a-spacing-base&quot;]/input[@class=&quot;a-input-text a-span12 cvf-widget-input cvf-widget-input-code cvf-widget-input-captcha fwcim-captcha-guess&quot;]&quot;) or . = concat(&quot;{}






  
    

    
      



  
  

  
  
    
    
      

    
      
    
  


    
  










Solve this puzzle to protect your account






       Enter the letters and numbers above 





      
          See new characters
        
        
            Hear the characters
          

    
&lt;div class=&quot;a-row a-spacing-mini&quot;>&lt;span class=&quot;a-button a-button-span12 a-button-base cvf-widget-btn-captcha cvf-widget-btn-new-captcha&quot;>&lt;span class=&quot;a-button-inner&quot;>&lt;input name=&quot;cvf_captcha_captcha_action&quot; class=&quot;a-button-input notranslate&quot; type=&quot;submit&quot; value=&quot;newCaptcha&quot;/>&lt;span class=&quot;a-button-text&quot; aria-hidden=&quot;true&quot;>          See new characters
&lt;/span>&lt;/span>&lt;/span>&lt;/div>    

    
&lt;div class=&quot;a-row a-spacing-mini&quot;>&lt;span class=&quot;a-button a-button-span12 a-button-base cvf-widget-btn-captcha cvf-widget-btn-alternative-captcha&quot;>&lt;span class=&quot;a-button-inner&quot;>&lt;input name=&quot;cvf_captcha_captcha_action&quot; class=&quot;a-button-input notranslate&quot; type=&quot;submit&quot; value=&quot;alternativeCaptcha&quot;/>&lt;span class=&quot;a-button-text&quot; aria-hidden=&quot;true&quot;>          Hear the characters
&lt;/span>&lt;/span>&lt;/span>&lt;/div>    

Continue

  
    P.when(&quot; , &quot;'&quot; , &quot;A&quot; , &quot;'&quot; , &quot;).execute(function(A){
      var $ = A.$;
      $(&quot; , &quot;'&quot; , &quot;#cvf_captcha_js_enabled_metric_id&quot; , &quot;'&quot; , &quot;).val(&quot;1&quot;);
    });
  







  .auth-footer-separator {
    display: inline-block;
    width: 20px;
  }





  
    
      
    

    
      
        
          
        

        
      

      
        

        
          
            Conditions of Use
          
        
      

      
    
      
        
          
        

        
      

      
        

        
          
            Privacy Notice
          
        
      

      
    
      
        
          
        

        
      

      
        

        
          
            Help
          
        
      

      
    
  

  
    
      © 1996-2024, Amazon.com, Inc. or its affiliates
    
  



id(&quot;cvf-page-content&quot;)/div[@class=&quot;a-row a-spacing-none&quot;]/div[@class=&quot;a-box&quot;]/div[@class=&quot;a-box-inner a-padding-extra-large&quot;]/form[@class=&quot;cvf-widget-form cvf-widget-form-captcha fwcim-form a-spacing-none&quot;]/div[@class=&quot;a-row a-spacing-base&quot;]/input[@class=&quot;a-input-text a-span12 cvf-widget-input cvf-widget-input-code cvf-widget-input-captcha fwcim-captcha-guess&quot;]&quot;))]</value>
      <webElementGuid>11f03a9b-01fa-4019-9798-820b467d42c2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
